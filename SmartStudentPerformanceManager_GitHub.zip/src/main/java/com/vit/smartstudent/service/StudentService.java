package com.vit.smartstudent.service;
import com.vit.smartstudent.model.Student; import com.vit.smartstudent.util.InputValidator; import java.util.*;
public class StudentService {
    private final List<Student> students; private final DataStore store;
    public StudentService(DataStore s){store=s;students=new ArrayList<>(s.loadStudents());}
    public void add(Student x){InputValidator.require(find(x.getId()).isEmpty(),"Student ID already exists.");InputValidator.validName(x.getName());InputValidator.validEmail(x.getEmail());InputValidator.validSemester(x.getSemester());students.add(x);store.saveStudents(students);}
    public Optional<Student> find(int id){return students.stream().filter(s->s.getId()==id).findFirst();}
    public List<Student> all(){return Collections.unmodifiableList(students);}
    public void update(int id,String n,String e,String b,int sem){Student s=find(id).orElseThrow(()->new NoSuchElementException("Student not found."));InputValidator.validName(n);InputValidator.validEmail(e);InputValidator.validSemester(sem);s.setName(n);s.setEmail(e);s.setBranch(b);s.setSemester(sem);store.saveStudents(students);}
    public void delete(int id){Student s=find(id).orElseThrow(()->new NoSuchElementException("Student not found."));students.remove(s);store.saveStudents(students);}
}

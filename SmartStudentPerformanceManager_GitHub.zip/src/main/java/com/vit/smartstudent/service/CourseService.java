package com.vit.smartstudent.service;
import com.vit.smartstudent.model.Course; import com.vit.smartstudent.util.InputValidator; import java.util.*;
public class CourseService {
    private final List<Course> courses; private final DataStore store;
    public CourseService(DataStore s){store=s;courses=new ArrayList<>(s.loadCourses());}
    public void add(Course c){InputValidator.require(find(c.getCode()).isEmpty(),"Course code already exists.");InputValidator.require(!c.getCode().isBlank(),"Course code cannot be empty.");InputValidator.require(!c.getName().isBlank(),"Course name cannot be empty.");InputValidator.validCredits(c.getCredits());courses.add(c);store.saveCourses(courses);}
    public Optional<Course> find(String code){return courses.stream().filter(c->c.getCode().equalsIgnoreCase(code)).findFirst();}
    public List<Course> all(){return Collections.unmodifiableList(courses);}
}

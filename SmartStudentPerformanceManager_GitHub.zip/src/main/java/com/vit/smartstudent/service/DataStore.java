package com.vit.smartstudent.service;
import com.vit.smartstudent.model.*; import java.io.IOException; import java.nio.file.*; import java.util.*; import java.util.function.Function;
public class DataStore {
    private final Path dir;
    public DataStore(String directory){dir=Paths.get(directory);try{Files.createDirectories(dir);}catch(IOException e){throw new IllegalStateException("Cannot create data directory",e);}}
    public List<Student> loadStudents(){return load("students.csv",Student::fromCsv);}
    public List<Course> loadCourses(){return load("courses.csv",Course::fromCsv);}
    public List<MarkRecord> loadMarks(){return load("marks.csv",MarkRecord::fromCsv);}
    public List<AttendanceRecord> loadAttendance(){return load("attendance.csv",AttendanceRecord::fromCsv);}
    public void saveStudents(Collection<Student> x){save("students.csv",x.stream().map(Student::toCsv).toList());}
    public void saveCourses(Collection<Course> x){save("courses.csv",x.stream().map(Course::toCsv).toList());}
    public void saveMarks(Collection<MarkRecord> x){save("marks.csv",x.stream().map(MarkRecord::toCsv).toList());}
    public void saveAttendance(Collection<AttendanceRecord> x){save("attendance.csv",x.stream().map(AttendanceRecord::toCsv).toList());}
    private <T> List<T> load(String f,Function<String,T> parser){Path p=dir.resolve(f);if(!Files.exists(p))return new ArrayList<>();try{List<T> r=new ArrayList<>();for(String line:Files.readAllLines(p))if(!line.isBlank())r.add(parser.apply(line));return r;}catch(Exception e){throw new IllegalStateException("Unable to read "+f,e);}}
    private void save(String f,List<String> lines){try{Files.write(dir.resolve(f),lines,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING);}catch(IOException e){throw new IllegalStateException("Unable to write "+f,e);}}
}

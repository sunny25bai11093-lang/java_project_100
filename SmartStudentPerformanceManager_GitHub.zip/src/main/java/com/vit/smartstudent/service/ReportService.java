package com.vit.smartstudent.service;
import com.vit.smartstudent.model.*; import java.util.*;
public class ReportService {
    private final StudentService students; private final AcademicService academics; private final CourseService courses;
    public ReportService(StudentService s,AcademicService a,CourseService c){students=s;academics=a;courses=c;}
    public String studentReport(int id){
        Student s=students.find(id).orElseThrow(()->new NoSuchElementException("Student not found."));
        StringBuilder o=new StringBuilder("\n========== STUDENT PERFORMANCE REPORT ==========\n");
        o.append("Student : ").append(s.getName()).append("\nID      : ").append(s.getId()).append("\nBranch  : ").append(s.getBranch()).append("\nSemester: ").append(s.getSemester()).append("\n\nCourse-wise performance:\n");
        for(MarkRecord m:academics.marksFor(id)){String n=courses.find(m.getCourseCode()).map(Course::getName).orElse("Unknown");o.append(String.format("  %-8s %-30s Marks: %6.2f%n",m.getCourseCode(),n,m.getMarks()));}
        o.append(String.format("\nAverage Marks      : %.2f/100%n",academics.averageMarks(id)));
        o.append(String.format("Average Attendance : %.2f%%%n",academics.averageAttendance(id)));
        double avg=academics.averageMarks(id);String status=avg>=75?"Excellent":avg>=60?"Good":avg>=50?"Satisfactory":"Needs Improvement";
        o.append("Academic Status    : ").append(status).append("\n===============================================\n");return o.toString();
    }
    public String classSummary(){StringBuilder o=new StringBuilder("\n============== CLASS SUMMARY ==============\n");for(Student s:students.all())o.append(String.format("%-20s | Marks: %6.2f | Attendance: %6.2f%%%n",s.getName(),academics.averageMarks(s.getId()),academics.averageAttendance(s.getId())));return o.append("============================================\n").toString();}
}

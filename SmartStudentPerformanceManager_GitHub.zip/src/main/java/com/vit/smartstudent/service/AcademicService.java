package com.vit.smartstudent.service;
import com.vit.smartstudent.model.*; import com.vit.smartstudent.util.InputValidator; import java.util.*;
public class AcademicService {
    private final List<MarkRecord> marks; private final List<AttendanceRecord> attendance; private final DataStore store; private final StudentService students; private final CourseService courses;
    public AcademicService(DataStore s,StudentService st,CourseService c){store=s;students=st;courses=c;marks=new ArrayList<>(s.loadMarks());attendance=new ArrayList<>(s.loadAttendance());}
    public void recordMarks(int id,String code,double value){validate(id,code);InputValidator.validMarks(value);marks.removeIf(m->m.getStudentId()==id&&m.getCourseCode().equalsIgnoreCase(code));marks.add(new MarkRecord(id,code.toUpperCase(),value));store.saveMarks(marks);}
    public void recordAttendance(int id,String code,int a,int t){validate(id,code);InputValidator.validAttendance(a,t);attendance.removeIf(x->x.getStudentId()==id&&x.getCourseCode().equalsIgnoreCase(code));attendance.add(new AttendanceRecord(id,code.toUpperCase(),a,t));store.saveAttendance(attendance);}
    public List<MarkRecord> marksFor(int id){return marks.stream().filter(m->m.getStudentId()==id).toList();}
    public List<AttendanceRecord> attendanceFor(int id){return attendance.stream().filter(a->a.getStudentId()==id).toList();}
    public double averageMarks(int id){return marksFor(id).stream().mapToDouble(MarkRecord::getMarks).average().orElse(0);}
    public double averageAttendance(int id){return attendanceFor(id).stream().mapToDouble(AttendanceRecord::percentage).average().orElse(0);}
    private void validate(int id,String code){InputValidator.require(students.find(id).isPresent(),"Student not found.");InputValidator.require(courses.find(code).isPresent(),"Course not found.");}
}

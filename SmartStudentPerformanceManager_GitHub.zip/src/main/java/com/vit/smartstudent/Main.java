package com.vit.smartstudent;
import com.vit.smartstudent.model.*; import com.vit.smartstudent.service.*; import java.util.*;
public class Main {
    private static final Scanner SC=new Scanner(System.in);
    public static void main(String[] args){
        DataStore store=new DataStore("data");StudentService students=new StudentService(store);CourseService courses=new CourseService(store);
        AcademicService academics=new AcademicService(store,students,courses);ReportService reports=new ReportService(students,academics,courses);seed(students,courses,academics);
        System.out.println("==============================================\n   SMART STUDENT PERFORMANCE MANAGER\n==============================================");
        boolean run=true;while(run){menu();String c=SC.nextLine().trim();try{switch(c){
            case "1"->addStudent(students);case "2"->students.all().forEach(System.out::println);case "3"->updateStudent(students);case "4"->students.delete(readInt("Student ID: "));
            case "5"->addCourse(courses);case "6"->courses.all().forEach(System.out::println);case "7"->recordMarks(academics);case "8"->recordAttendance(academics);
            case "9"->System.out.println(reports.studentReport(readInt("Student ID: ")));case "10"->System.out.println(reports.classSummary());case "0"->run=false;default->System.out.println("Invalid option.");
        }}catch(RuntimeException e){System.out.println("Operation failed: "+e.getMessage());}}System.out.println("Thank you for using the system.");}
    static void menu(){System.out.print("\n1.Add Student\n2.List Students\n3.Update Student\n4.Delete Student\n5.Add Course\n6.List Courses\n7.Record/Update Marks\n8.Record/Update Attendance\n9.Student Performance Report\n10.Class Summary\n0.Exit\nEnter choice: ");}
    static void addStudent(StudentService s){s.add(new Student(readInt("ID: "),read("Name: "),read("Email: "),read("Branch: "),readInt("Semester: ")));System.out.println("Student added successfully.");}
    static void updateStudent(StudentService s){int id=readInt("Student ID: ");s.update(id,read("New name: "),read("New email: "),read("New branch: "),readInt("New semester: "));System.out.println("Student updated successfully.");}
    static void addCourse(CourseService s){s.add(new Course(read("Course code: ").toUpperCase(),read("Course name: "),readInt("Credits: ")));System.out.println("Course added successfully.");}
    static void recordMarks(AcademicService a){a.recordMarks(readInt("Student ID: "),read("Course code: "),readDouble("Marks (0-100): "));System.out.println("Marks saved successfully.");}
    static void recordAttendance(AcademicService a){a.recordAttendance(readInt("Student ID: "),read("Course code: "),readInt("Classes attended: "),readInt("Total classes: "));System.out.println("Attendance saved successfully.");}
    static int readInt(String p){System.out.print(p);return Integer.parseInt(SC.nextLine().trim());}
    static double readDouble(String p){System.out.print(p);return Double.parseDouble(SC.nextLine().trim());}
    static String read(String p){System.out.print(p);return SC.nextLine().trim();}
    static void seed(StudentService s,CourseService c,AcademicService a){
        if(s.all().isEmpty()){s.add(new Student(101,"Aarav Sharma","aarav@example.com","AIML",4));s.add(new Student(102,"Diya Verma","diya@example.com","CSE",4));}
        if(c.all().isEmpty()){c.add(new Course("CSE2001","Programming in Java",4));c.add(new Course("CSE2002","Data Structures",4));c.add(new Course("MAT2001","Applied Mathematics",4));}
        if(a.marksFor(101).isEmpty()){a.recordMarks(101,"CSE2001",86);a.recordMarks(101,"CSE2002",79);a.recordMarks(101,"MAT2001",91);a.recordAttendance(101,"CSE2001",22,25);a.recordAttendance(101,"CSE2002",20,25);a.recordAttendance(101,"MAT2001",24,25);}
    }
}

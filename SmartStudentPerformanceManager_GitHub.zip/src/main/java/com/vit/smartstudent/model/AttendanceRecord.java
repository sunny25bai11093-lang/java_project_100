package com.vit.smartstudent.model;
public class AttendanceRecord {
    private final int studentId; private final String courseCode; private int attended,total;
    public AttendanceRecord(int studentId,String courseCode,int attended,int total){this.studentId=studentId;this.courseCode=courseCode;this.attended=attended;this.total=total;}
    public int getStudentId(){return studentId;} public String getCourseCode(){return courseCode;} public int getAttended(){return attended;} public int getTotal(){return total;}
    public void setAttendance(int a,int t){attended=a;total=t;} public double percentage(){return total==0?0:attended*100.0/total;}
    public String toCsv(){return studentId+","+courseCode+","+attended+","+total;}
    public static AttendanceRecord fromCsv(String line){String[] p=line.split(",",-1);if(p.length!=4)throw new IllegalArgumentException("Invalid attendance record");return new AttendanceRecord(Integer.parseInt(p[0]),p[1],Integer.parseInt(p[2]),Integer.parseInt(p[3]));}
}

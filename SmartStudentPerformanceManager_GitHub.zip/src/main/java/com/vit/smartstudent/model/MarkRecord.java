package com.vit.smartstudent.model;
public class MarkRecord {
    private final int studentId; private final String courseCode; private double marks;
    public MarkRecord(int studentId,String courseCode,double marks){this.studentId=studentId;this.courseCode=courseCode;this.marks=marks;}
    public int getStudentId(){return studentId;} public String getCourseCode(){return courseCode;} public double getMarks(){return marks;}
    public void setMarks(double v){marks=v;} public String toCsv(){return studentId+","+courseCode+","+marks;}
    public static MarkRecord fromCsv(String line){String[] p=line.split(",",-1);if(p.length!=3)throw new IllegalArgumentException("Invalid mark record");return new MarkRecord(Integer.parseInt(p[0]),p[1],Double.parseDouble(p[2]));}
}

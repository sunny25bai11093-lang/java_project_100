package com.vit.smartstudent.model;

public class Student {
    private final int id; private String name, email, branch; private int semester;
    public Student(int id,String name,String email,String branch,int semester){this.id=id;this.name=name;this.email=email;this.branch=branch;this.semester=semester;}
    public int getId(){return id;} public String getName(){return name;} public String getEmail(){return email;}
    public String getBranch(){return branch;} public int getSemester(){return semester;}
    public void setName(String v){name=v;} public void setEmail(String v){email=v;} public void setBranch(String v){branch=v;} public void setSemester(int v){semester=v;}
    public String toCsv(){return id+","+clean(name)+","+clean(email)+","+clean(branch)+","+semester;}
    private String clean(String v){return v.replace(","," ");}
    public static Student fromCsv(String line){String[] p=line.split(",",-1);if(p.length!=5)throw new IllegalArgumentException("Invalid student record");return new Student(Integer.parseInt(p[0]),p[1],p[2],p[3],Integer.parseInt(p[4]));}
    public String toString(){return String.format("ID: %d | %-20s | %-28s | %-8s | Sem %d",id,name,email,branch,semester);}
}

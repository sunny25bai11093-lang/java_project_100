package com.vit.smartstudent.model;

public class Course {
    private final String code; private String name; private int credits;
    public Course(String code,String name,int credits){this.code=code;this.name=name;this.credits=credits;}
    public String getCode(){return code;} public String getName(){return name;} public int getCredits(){return credits;}
    public void setName(String v){name=v;} public void setCredits(int v){credits=v;}
    public String toCsv(){return code+","+name.replace(","," ")+","+credits;}
    public static Course fromCsv(String line){String[] p=line.split(",",-1);if(p.length!=3)throw new IllegalArgumentException("Invalid course record");return new Course(p[0],p[1],Integer.parseInt(p[2]));}
    public String toString(){return String.format("%-8s | %-35s | %d credits",code,name,credits);}
}

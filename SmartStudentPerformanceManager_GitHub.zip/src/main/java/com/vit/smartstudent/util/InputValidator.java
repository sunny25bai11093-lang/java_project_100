package com.vit.smartstudent.util;
import java.util.regex.Pattern;
public final class InputValidator {
    private static final Pattern EMAIL=Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private InputValidator(){}
    public static void require(boolean c,String m){if(!c)throw new IllegalArgumentException(m);}
    public static void validName(String v){require(v!=null&&!v.isBlank(),"Name cannot be empty.");}
    public static void validEmail(String v){require(v!=null&&EMAIL.matcher(v).matches(),"Enter a valid email address.");}
    public static void validSemester(int v){require(v>=1&&v<=8,"Semester must be between 1 and 8.");}
    public static void validCredits(int v){require(v>=1&&v<=10,"Credits must be between 1 and 10.");}
    public static void validMarks(double v){require(v>=0&&v<=100,"Marks must be between 0 and 100.");}
    public static void validAttendance(int a,int t){require(t>=0&&a>=0&&a<=t,"Attendance must satisfy 0 <= attended <= total.");}
}

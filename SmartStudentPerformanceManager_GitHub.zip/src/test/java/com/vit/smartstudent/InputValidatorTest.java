package com.vit.smartstudent;
import com.vit.smartstudent.util.InputValidator; import org.junit.jupiter.api.Test; import static org.junit.jupiter.api.Assertions.*;
class InputValidatorTest {
 @Test void validMarksAccepted(){assertDoesNotThrow(()->InputValidator.validMarks(75));}
 @Test void invalidMarksRejected(){assertThrows(IllegalArgumentException.class,()->InputValidator.validMarks(101));}
 @Test void attendanceCannotExceedTotal(){assertThrows(IllegalArgumentException.class,()->InputValidator.validAttendance(26,25));}
}

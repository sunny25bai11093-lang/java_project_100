package com.vit.smartstudent;
import com.vit.smartstudent.model.AttendanceRecord; import org.junit.jupiter.api.Test; import static org.junit.jupiter.api.Assertions.*;
class AttendanceRecordTest {
 @Test void percentage(){assertEquals(88.0,new AttendanceRecord(1,"JAVA",22,25).percentage(),0.001);}
 @Test void zeroTotal(){assertEquals(0.0,new AttendanceRecord(1,"JAVA",0,0).percentage(),0.001);}
}
